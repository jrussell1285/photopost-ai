const MAX_PHOTOS = 8;
const MAX_UPLOAD_CHARACTERS = 3_350_000;
const state = {
  files: [],
  compressedImages: [],
  selectedCaptionIndex: 0,
  result: null,
  deferredInstallPrompt: null
};

const $ = id => document.getElementById(id);
const els = {
  photoInput: $("photoInput"),
  dropZone: $("dropZone"),
  photoGrid: $("photoGrid"),
  photoCount: $("photoCount"),
  profileSelect: $("profileSelect"),
  postType: $("postType"),
  tone: $("tone"),
  platform: $("platform"),
  length: $("length"),
  location: $("location"),
  context: $("context"),
  callToAction: $("callToAction"),
  profileName: $("profileName"),
  profileDescription: $("profileDescription"),
  saveProfileBtn: $("saveProfileBtn"),
  deleteProfileBtn: $("deleteProfileBtn"),
  generateBtn: $("generateBtn"),
  generateLabel: $("generateLabel"),
  formError: $("formError"),
  resultsCard: $("resultsCard"),
  resultMode: $("resultMode"),
  photoSummary: $("photoSummary"),
  captionOptions: $("captionOptions"),
  hashtagsOutput: $("hashtagsOutput"),
  platformNote: $("platformNote"),
  copyHashtagsBtn: $("copyHashtagsBtn"),
  shareBtn: $("shareBtn"),
  copyAllBtn: $("copyAllBtn"),
  saveDraftBtn: $("saveDraftBtn"),
  newPostBtn: $("newPostBtn"),
  aiStatus: $("aiStatus"),
  installBtn: $("installBtn"),
  draftList: $("draftList"),
  toast: $("toast"),
  captionTemplate: $("captionTemplate")
};

const defaultProfiles = [
  {
    id: "personal",
    name: "Personal",
    description: "Personal photos, friends, family, travel, food and hobbies."
  },
  {
    id: "russells-plumbing",
    name: "Russell's Plumbing LLC",
    description: "Florida plumbing company. Clear, trustworthy service updates with practical calls to action."
  },
  {
    id: "nature-coast-bourbon",
    name: "Nature Coast Bourbon Society",
    description: "Florida bourbon group sharing tastings, bottle shares, distillery trips and whiskey finds."
  }
];

function getProfiles() {
  const stored = localStorage.getItem("photopost_profiles");
  if (!stored) {
    localStorage.setItem("photopost_profiles", JSON.stringify(defaultProfiles));
    return structuredClone(defaultProfiles);
  }
  try {
    const parsed = JSON.parse(stored);
    return Array.isArray(parsed) && parsed.length ? parsed : structuredClone(defaultProfiles);
  } catch {
    return structuredClone(defaultProfiles);
  }
}

function saveProfiles(profiles) {
  localStorage.setItem("photopost_profiles", JSON.stringify(profiles));
}

function renderProfiles(selectedId) {
  const profiles = getProfiles();
  els.profileSelect.innerHTML = "";
  for (const profile of profiles) {
    const option = document.createElement("option");
    option.value = profile.id;
    option.textContent = profile.name;
    els.profileSelect.append(option);
  }
  const chosen = profiles.find(p => p.id === selectedId) || profiles[0];
  els.profileSelect.value = chosen.id;
  syncProfileEditor();
}

function syncProfileEditor() {
  const profile = getProfiles().find(p => p.id === els.profileSelect.value);
  els.profileName.value = profile?.name || "";
  els.profileDescription.value = profile?.description || "";
}

function slugify(value) {
  return String(value || "profile")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 45) || `profile-${Date.now()}`;
}

function saveCurrentProfile() {
  const name = els.profileName.value.trim();
  const description = els.profileDescription.value.trim();
  if (!name) return showToast("Enter a profile name.");
  const profiles = getProfiles();
  const currentId = els.profileSelect.value;
  const index = profiles.findIndex(p => p.id === currentId);
  const profile = { id: currentId || slugify(name), name, description };
  if (index >= 0) profiles[index] = profile;
  else profiles.push(profile);
  saveProfiles(profiles);
  renderProfiles(profile.id);
  showToast("Profile saved.");
}

function deleteCurrentProfile() {
  const profiles = getProfiles();
  if (profiles.length <= 1) return showToast("Keep at least one profile.");
  const filtered = profiles.filter(p => p.id !== els.profileSelect.value);
  saveProfiles(filtered);
  renderProfiles(filtered[0].id);
  showToast("Profile deleted.");
}

async function handleFiles(fileList) {
  const incoming = Array.from(fileList || []).filter(file => file.type.startsWith("image/"));
  const space = MAX_PHOTOS - state.files.length;
  if (space <= 0) return showToast(`Maximum ${MAX_PHOTOS} photos.`);
  const chosen = incoming.slice(0, space);

  setBusy(true, "Preparing photos…");
  try {
    for (const file of chosen) {
      const compressed = await compressImage(file);
      state.files.push(file);
      state.compressedImages.push(compressed);
    }
    renderPhotos();
    if (incoming.length > space) showToast(`Only the first ${space} additional photos were added.`);
  } catch (error) {
    showError(error.message || "One of the photos could not be prepared.");
  } finally {
    setBusy(false);
    els.photoInput.value = "";
  }
}

function compressImage(file, options = {}) {
  const targetCharacters = Number(options.targetCharacters || 0);
  const startingDimension = Number(options.maxDimension || 1200);
  const startingQuality = Number(options.quality || 0.72);

  return new Promise((resolve, reject) => {
    const image = new Image();
    const url = URL.createObjectURL(file);

    image.onload = () => {
      try {
        let dimension = startingDimension;
        let lastDataUrl = "";

        while (dimension >= 460) {
          const scale = Math.min(
            1,
            dimension / Math.max(image.naturalWidth, image.naturalHeight)
          );
          const width = Math.max(1, Math.round(image.naturalWidth * scale));
          const height = Math.max(1, Math.round(image.naturalHeight * scale));
          const canvas = document.createElement("canvas");
          canvas.width = width;
          canvas.height = height;

          const ctx = canvas.getContext("2d", { alpha: false });
          ctx.fillStyle = "#ffffff";
          ctx.fillRect(0, 0, width, height);
          ctx.drawImage(image, 0, 0, width, height);

          for (const quality of [startingQuality, 0.64, 0.56, 0.48, 0.42]) {
            lastDataUrl = canvas.toDataURL("image/jpeg", quality);
            if (!targetCharacters || lastDataUrl.length <= targetCharacters) {
              resolve(lastDataUrl);
              return;
            }
          }

          dimension = Math.floor(dimension * 0.82);
        }

        resolve(lastDataUrl);
      } catch (error) {
        reject(error);
      } finally {
        URL.revokeObjectURL(url);
      }
    };

    image.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error(`Could not read ${file.name}.`));
    };

    image.src = url;
  });
}

async function prepareUploadImages() {
  if (!state.files.length) return [];

  const perImageBudget = Math.floor(MAX_UPLOAD_CHARACTERS / state.files.length);
  const prepared = [];

  for (const file of state.files) {
    prepared.push(await compressImage(file, {
      maxDimension: 1400,
      quality: 0.76,
      targetCharacters: perImageBudget
    }));
  }

  const totalCharacters = prepared.reduce((sum, image) => sum + image.length, 0);
  if (totalCharacters > MAX_UPLOAD_CHARACTERS) {
    throw new Error("The prepared photos are too large. Remove one photo and try again.");
  }

  return prepared;
}

function renderPhotos() {
  els.photoGrid.innerHTML = "";
  state.files.forEach((file, index) => {
    const item = document.createElement("div");
    item.className = "photo-item";

    const img = document.createElement("img");
    img.alt = `Selected photo ${index + 1}`;
    const previewUrl = URL.createObjectURL(file);
    img.src = previewUrl;
    img.onload = () => URL.revokeObjectURL(previewUrl);

    const number = document.createElement("span");
    number.className = "photo-number";
    number.textContent = index + 1;

    const actions = document.createElement("div");
    actions.className = "photo-actions";

    const left = actionButton("←", "Move photo left", () => movePhoto(index, -1));
    const remove = actionButton("Remove", "Remove photo", () => removePhoto(index), "remove-photo");
    const right = actionButton("→", "Move photo right", () => movePhoto(index, 1));
    left.disabled = index === 0;
    right.disabled = index === state.files.length - 1;

    actions.append(left, remove, right);
    item.append(img, number, actions);
    els.photoGrid.append(item);
  });
  els.photoCount.textContent = `${state.files.length} / ${MAX_PHOTOS}`;
}

function actionButton(text, label, handler, className = "") {
  const button = document.createElement("button");
  button.type = "button";
  button.textContent = text;
  button.setAttribute("aria-label", label);
  button.className = className;
  button.addEventListener("click", handler);
  return button;
}

function movePhoto(index, direction) {
  const target = index + direction;
  if (target < 0 || target >= state.files.length) return;
  [state.files[index], state.files[target]] = [state.files[target], state.files[index]];
  [state.compressedImages[index], state.compressedImages[target]] =
    [state.compressedImages[target], state.compressedImages[index]];
  renderPhotos();
}

function removePhoto(index) {
  state.files.splice(index, 1);
  state.compressedImages.splice(index, 1);
  renderPhotos();
}

function selectedProfile() {
  return getProfiles().find(p => p.id === els.profileSelect.value) || getProfiles()[0];
}

function settingsPayload() {
  const profile = selectedProfile();
  return {
    profileName: profile.name,
    profileDescription: profile.description,
    postType: els.postType.value,
    tone: els.tone.value,
    platform: els.platform.value,
    length: els.length.value,
    location: els.location.value.trim(),
    context: els.context.value.trim(),
    callToAction: els.callToAction.value.trim()
  };
}

async function generatePost() {
  hideError();
  if (!state.files.length) return showError("Add at least one photo first.");

  setBusy(true, "Preparing photos…");
  try {
    const uploadImages = await prepareUploadImages();
    setBusy(true, "Analyzing photos…");

    const response = await fetch("/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        images: uploadImages,
        settings: settingsPayload()
      })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not create the post.");

    state.result = data;
    state.selectedCaptionIndex = 0;
    renderResults();
    els.resultsCard.classList.remove("hidden");
    els.resultsCard.scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (error) {
    showError(error.message || "Could not create the post.");
  } finally {
    setBusy(false);
  }
}

function renderResults() {
  const result = state.result;
  els.resultMode.textContent = result.mode === "ai" ? "AI photo analysis" : "Fallback mode";
  els.resultMode.className = `status-pill compact ${result.mode === "ai" ? "connected" : "fallback"}`;
  els.photoSummary.textContent = result.photoSummary || "";
  els.captionOptions.innerHTML = "";

  result.captions.forEach((caption, index) => {
    const fragment = els.captionTemplate.content.cloneNode(true);
    const card = fragment.querySelector(".caption-card");
    const label = fragment.querySelector(".caption-label");
    const textarea = fragment.querySelector(".caption-text");
    const radio = fragment.querySelector(".caption-choice");
    const copyButton = fragment.querySelector(".copy-caption");

    label.textContent = caption.label;
    textarea.value = caption.text;
    radio.value = index;
    radio.checked = index === state.selectedCaptionIndex;
    if (radio.checked) card.classList.add("selected");

    textarea.addEventListener("input", () => {
      state.result.captions[index].text = textarea.value;
    });
    radio.addEventListener("change", () => {
      state.selectedCaptionIndex = index;
      [...els.captionOptions.querySelectorAll(".caption-card")].forEach((el, i) => {
        el.classList.toggle("selected", i === index);
      });
    });
    copyButton.addEventListener("click", () => copyText(textarea.value, "Caption copied."));

    els.captionOptions.append(fragment);
  });

  els.hashtagsOutput.value = (result.hashtags || []).join(" ");
  els.platformNote.textContent = result.recommendedPlatformNotes || "";
}

function currentCaption() {
  return state.result?.captions?.[state.selectedCaptionIndex]?.text?.trim() || "";
}

function completePostText() {
  const caption = currentCaption();
  const hashtags = els.hashtagsOutput.value.trim();
  return [caption, hashtags].filter(Boolean).join("\n\n");
}

async function sharePost() {
  if (!state.result) return;
  const text = completePostText();
  const shareData = { title: "Social media post", text };
  const shareableFiles = state.files.filter(file => file instanceof File);

  try {
    if (shareableFiles.length && navigator.canShare?.({ files: shareableFiles })) {
      shareData.files = shareableFiles;
    }
    if (navigator.share) {
      await navigator.share(shareData);
    } else {
      await copyText(text, "Post copied. Open your social app and paste it.");
    }
  } catch (error) {
    if (error.name !== "AbortError") {
      await copyText(text, "Sharing was not available, so the post was copied.");
    }
  }
}

async function copyText(text, successMessage = "Copied.") {
  try {
    await navigator.clipboard.writeText(text);
    showToast(successMessage);
  } catch {
    const helper = document.createElement("textarea");
    helper.value = text;
    helper.style.position = "fixed";
    helper.style.opacity = "0";
    document.body.append(helper);
    helper.select();
    document.execCommand("copy");
    helper.remove();
    showToast(successMessage);
  }
}

function saveDraft() {
  if (!state.result) return;
  const drafts = getDrafts();
  drafts.unshift({
    id: crypto.randomUUID?.() || String(Date.now()),
    savedAt: new Date().toISOString(),
    profileName: selectedProfile().name,
    platform: els.platform.value,
    caption: currentCaption(),
    hashtags: els.hashtagsOutput.value.trim()
  });
  localStorage.setItem("photopost_drafts", JSON.stringify(drafts.slice(0, 30)));
  renderDrafts();
  showToast("Draft saved on this device.");
}

function getDrafts() {
  try {
    const parsed = JSON.parse(localStorage.getItem("photopost_drafts") || "[]");
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function renderDrafts() {
  const drafts = getDrafts();
  els.draftList.innerHTML = "";
  if (!drafts.length) {
    const empty = document.createElement("p");
    empty.className = "muted";
    empty.textContent = "No saved drafts yet.";
    els.draftList.append(empty);
    return;
  }

  drafts.forEach(draft => {
    const item = document.createElement("article");
    item.className = "draft-item";
    const heading = document.createElement("strong");
    heading.textContent = `${draft.profileName} • ${draft.platform}`;
    const date = document.createElement("small");
    date.className = "muted";
    date.textContent = new Date(draft.savedAt).toLocaleString();
    const text = document.createElement("p");
    text.textContent = draft.caption;
    const actions = document.createElement("div");
    actions.className = "draft-actions";
    const copy = actionButton("Copy", "Copy saved draft", () =>
      copyText([draft.caption, draft.hashtags].filter(Boolean).join("\n\n"), "Draft copied.")
    );
    copy.className = "secondary";
    const remove = actionButton("Delete", "Delete saved draft", () => {
      const updated = getDrafts().filter(item => item.id !== draft.id);
      localStorage.setItem("photopost_drafts", JSON.stringify(updated));
      renderDrafts();
    });
    remove.className = "ghost danger";
    actions.append(copy, remove);
    item.append(heading, document.createElement("br"), date, text, actions);
    els.draftList.append(item);
  });
}

function clearPost() {
  state.files = [];
  state.compressedImages = [];
  state.result = null;
  renderPhotos();
  els.context.value = "";
  els.location.value = "";
  els.callToAction.value = "";
  els.resultsCard.classList.add("hidden");
  hideError();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function setBusy(isBusy, label = "Create my post") {
  els.generateBtn.disabled = isBusy;
  els.generateLabel.textContent = isBusy ? label : "Create my post";
}

function showError(message) {
  els.formError.textContent = message;
  els.formError.classList.remove("hidden");
}

function hideError() {
  els.formError.textContent = "";
  els.formError.classList.add("hidden");
}

let toastTimer;
function showToast(message) {
  clearTimeout(toastTimer);
  els.toast.textContent = message;
  els.toast.classList.remove("hidden");
  toastTimer = setTimeout(() => els.toast.classList.add("hidden"), 2600);
}

async function checkStatus() {
  try {
    const response = await fetch("/api/status");
    const status = await response.json();
    if (status.aiConnected) {
      els.aiStatus.textContent = "AI photo analysis connected";
      els.aiStatus.className = "status-pill connected";
    } else {
      els.aiStatus.textContent = "Fallback mode — AI key not connected";
      els.aiStatus.className = "status-pill fallback";
    }
  } catch {
    els.aiStatus.textContent = "App is offline";
    els.aiStatus.className = "status-pill fallback";
  }
}

els.photoInput.addEventListener("change", event => handleFiles(event.target.files));
els.dropZone.addEventListener("dragover", event => {
  event.preventDefault();
  els.dropZone.classList.add("dragover");
});
els.dropZone.addEventListener("dragleave", () => els.dropZone.classList.remove("dragover"));
els.dropZone.addEventListener("drop", event => {
  event.preventDefault();
  els.dropZone.classList.remove("dragover");
  handleFiles(event.dataTransfer.files);
});
els.profileSelect.addEventListener("change", syncProfileEditor);
els.saveProfileBtn.addEventListener("click", saveCurrentProfile);
els.deleteProfileBtn.addEventListener("click", deleteCurrentProfile);
els.generateBtn.addEventListener("click", generatePost);
els.copyHashtagsBtn.addEventListener("click", () => copyText(els.hashtagsOutput.value, "Hashtags copied."));
els.shareBtn.addEventListener("click", sharePost);
els.copyAllBtn.addEventListener("click", () => copyText(completePostText(), "Complete post copied."));
els.saveDraftBtn.addEventListener("click", saveDraft);
els.newPostBtn.addEventListener("click", clearPost);

window.addEventListener("beforeinstallprompt", event => {
  event.preventDefault();
  state.deferredInstallPrompt = event;
  els.installBtn.classList.remove("hidden");
});
els.installBtn.addEventListener("click", async () => {
  if (!state.deferredInstallPrompt) return;
  state.deferredInstallPrompt.prompt();
  await state.deferredInstallPrompt.userChoice;
  state.deferredInstallPrompt = null;
  els.installBtn.classList.add("hidden");
});

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("/sw.js").catch(() => {}));
}

renderProfiles("personal");
renderPhotos();
renderDrafts();
checkStatus();
