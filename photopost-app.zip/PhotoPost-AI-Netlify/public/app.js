const MAX_PHOTOS = 8;
const MAX_UPLOAD_CHARACTERS = 3_350_000;
const PROFILE_STORAGE = "photopost_profiles_v2";
const SETTINGS_STORAGE = "photopost_profile_settings_v2";
const DRAFT_STORAGE = "photopost_drafts_v2";
const RECENT_STORAGE = "photopost_recent_posts_v2";

const state = {
  files: [],
  compressedImages: [],
  selectedCaptionIndex: 0,
  result: null,
  deferredInstallPrompt: null,
  mode: "quick"
};

const $ = id => document.getElementById(id);
const els = {
  photoInput: $("photoInput"),
  dropZone: $("dropZone"),
  photoGrid: $("photoGrid"),
  photoCount: $("photoCount"),
  profileSelect: $("profileSelect"),
  postGoal: $("postGoal"),
  platform: $("platform"),
  postType: $("postType"),
  context: $("context"),
  guidedFields: $("guidedFields"),
  tone: $("tone"),
  length: $("length"),
  emojiLevel: $("emojiLevel"),
  hashtagLevel: $("hashtagLevel"),
  factMode: $("factMode"),
  location: $("location"),
  mustInclude: $("mustInclude"),
  callToAction: $("callToAction"),
  avoidPhrases: $("avoidPhrases"),
  rememberSettings: $("rememberSettings"),
  profileName: $("profileName"),
  profileDescription: $("profileDescription"),
  profileDefaultPlatform: $("profileDefaultPlatform"),
  profileDefaultTone: $("profileDefaultTone"),
  profileHashtags: $("profileHashtags"),
  profileVoice: $("profileVoice"),
  profileAvoid: $("profileAvoid"),
  saveProfileBtn: $("saveProfileBtn"),
  deleteProfileBtn: $("deleteProfileBtn"),
  generateBtn: $("generateBtn"),
  generateLabel: $("generateLabel"),
  formError: $("formError"),
  resultsCard: $("resultsCard"),
  resultMode: $("resultMode"),
  photoSummary: $("photoSummary"),
  factCheckDetails: $("factCheckDetails"),
  visibleFacts: $("visibleFacts"),
  checkBeforePosting: $("checkBeforePosting"),
  checkBeforePostingGroup: $("checkBeforePostingGroup"),
  captionOptions: $("captionOptions"),
  postOutput: $("postOutput"),
  hashtagsOutput: $("hashtagsOutput"),
  altTextOutput: $("altTextOutput"),
  platformNote: $("platformNote"),
  copyPostBtn: $("copyPostBtn"),
  copyAltTextBtn: $("copyAltTextBtn"),
  shareBtn: $("shareBtn"),
  copyAllBtn: $("copyAllBtn"),
  saveStyleBtn: $("saveStyleBtn"),
  saveDraftBtn: $("saveDraftBtn"),
  newPostBtn: $("newPostBtn"),
  aiStatus: $("aiStatus"),
  installBtn: $("installBtn"),
  draftList: $("draftList"),
  toast: $("toast"),
  captionTemplate: $("captionTemplate")
};

const defaultProfiles = [
  {
    id: "personal",
    name: "Personal",
    description: "Everyday photos, family, trips, food, finds and hobbies.",
    defaultPlatform: "Facebook",
    defaultTone: "Natural",
    standardHashtags: "",
    voice: "Write like a real person texting friends. Specific, relaxed and not overly polished. Avoid generic enthusiasm.",
    avoid: "had to share, little look, one for the camera roll, game changer, excessive em dashes"
  },
  {
    id: "russells-plumbing",
    name: "Russell's Plumbing LLC",
    description: "Florida plumbing company sharing completed work, useful maintenance information and service updates.",
    defaultPlatform: "Facebook",
    defaultTone: "Professional",
    standardHashtags: "#RussellsPlumbing",
    voice: "Clear, local and trustworthy. Explain what was fixed in plain language. Sound experienced without bragging. Calls to action should be practical.",
    avoid: "best in the business, game changer, flawless, over-the-top sales language"
  },
  {
    id: "nature-coast-bourbon",
    name: "Nature Coast Bourbon Society",
    description: "Florida bourbon group sharing pours, bottle finds, tastings, distillery trips and whiskey conversations.",
    defaultPlatform: "Facebook",
    defaultTone: "Natural",
    standardHashtags: "#Bourbon",
    voice: "Knowledgeable but conversational. Use exact bottle facts when visible or supplied. Never claim a bottle was tasted, purchased or opened unless the user says so. Avoid macho whiskey clichés.",
    avoid: "won't be shy, tasting gets serious, liquid gold, smooth as silk, skull on the label unless relevant"
  }
];

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function getProfiles() {
  try {
    const stored = JSON.parse(localStorage.getItem(PROFILE_STORAGE) || "null");
    if (Array.isArray(stored) && stored.length) return stored.map(upgradeProfile);
  } catch {}
  const profiles = clone(defaultProfiles);
  localStorage.setItem(PROFILE_STORAGE, JSON.stringify(profiles));
  return profiles;
}

function upgradeProfile(profile) {
  const fallback = defaultProfiles.find(item => item.id === profile.id) || defaultProfiles[0];
  return {
    id: profile.id || slugify(profile.name || "profile"),
    name: profile.name || fallback.name,
    description: profile.description || fallback.description,
    defaultPlatform: profile.defaultPlatform || fallback.defaultPlatform,
    defaultTone: profile.defaultTone || fallback.defaultTone,
    standardHashtags: profile.standardHashtags || "",
    voice: profile.voice || fallback.voice,
    avoid: profile.avoid || fallback.avoid
  };
}

function saveProfiles(profiles) {
  localStorage.setItem(PROFILE_STORAGE, JSON.stringify(profiles));
}

function renderProfiles(selectedId) {
  const profiles = getProfiles();
  els.profileSelect.innerHTML = "";
  profiles.forEach(profile => {
    const option = document.createElement("option");
    option.value = profile.id;
    option.textContent = profile.name;
    els.profileSelect.append(option);
  });
  const chosen = profiles.find(profile => profile.id === selectedId) || profiles[0];
  els.profileSelect.value = chosen.id;
  syncProfileEditor();
  restoreSettingsForProfile(chosen.id, true);
}

function selectedProfile() {
  return getProfiles().find(profile => profile.id === els.profileSelect.value) || getProfiles()[0];
}

function syncProfileEditor() {
  const profile = selectedProfile();
  els.profileName.value = profile.name;
  els.profileDescription.value = profile.description;
  els.profileDefaultPlatform.value = profile.defaultPlatform;
  els.profileDefaultTone.value = profile.defaultTone;
  els.profileHashtags.value = profile.standardHashtags || "";
  els.profileVoice.value = profile.voice || "";
  els.profileAvoid.value = profile.avoid || "";
}

function slugify(value) {
  return String(value || "profile")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 45) || `profile-${Date.now()}`;
}

function saveCurrentProfile() {
  const name = els.profileName.value.trim();
  if (!name) return showToast("Enter a profile name.");

  const profiles = getProfiles();
  const currentId = els.profileSelect.value || slugify(name);
  const next = {
    id: currentId,
    name,
    description: els.profileDescription.value.trim(),
    defaultPlatform: els.profileDefaultPlatform.value,
    defaultTone: els.profileDefaultTone.value,
    standardHashtags: els.profileHashtags.value.trim(),
    voice: els.profileVoice.value.trim(),
    avoid: els.profileAvoid.value.trim()
  };

  const index = profiles.findIndex(profile => profile.id === currentId);
  if (index >= 0) profiles[index] = next;
  else profiles.push(next);

  saveProfiles(profiles);
  renderProfiles(currentId);
  showToast("Profile and writing voice saved.");
}

function deleteCurrentProfile() {
  const profiles = getProfiles();
  if (profiles.length <= 1) return showToast("Keep at least one profile.");
  const filtered = profiles.filter(profile => profile.id !== els.profileSelect.value);
  saveProfiles(filtered);
  renderProfiles(filtered[0].id);
  showToast("Profile deleted.");
}

function getProfileSettings() {
  try {
    const parsed = JSON.parse(localStorage.getItem(SETTINGS_STORAGE) || "{}");
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

function currentSettings() {
  return {
    postGoal: els.postGoal.value,
    platform: els.platform.value,
    postType: els.postType.value,
    tone: els.tone.value,
    length: els.length.value,
    emojiLevel: els.emojiLevel.value,
    hashtagLevel: els.hashtagLevel.value,
    factMode: els.factMode.value,
    location: els.location.value.trim(),
    callToAction: els.callToAction.value.trim(),
    avoidPhrases: els.avoidPhrases.value.trim(),
    mode: state.mode
  };
}

function saveSettingsForProfile() {
  if (!els.rememberSettings.checked) return;
  const all = getProfileSettings();
  all[els.profileSelect.value] = currentSettings();
  localStorage.setItem(SETTINGS_STORAGE, JSON.stringify(all));
}

function restoreSettingsForProfile(profileId, useProfileDefaults = false) {
  const profile = getProfiles().find(item => item.id === profileId) || getProfiles()[0];
  const saved = getProfileSettings()[profileId];

  const settings = saved || {
    postGoal: profile.id === "russells-plumbing" ? "Business update" : "Share a moment",
    platform: profile.defaultPlatform || "Facebook",
    postType: profile.id === "russells-plumbing"
      ? "Business"
      : profile.id === "nature-coast-bourbon"
        ? "Bourbon or hobby"
        : "Personal",
    tone: profile.defaultTone || "Natural",
    length: "Medium",
    emojiLevel: "None",
    hashtagLevel: "Few",
    factMode: "careful",
    location: "",
    callToAction: "",
    avoidPhrases: "",
    mode: "quick"
  };

  els.postGoal.value = settings.postGoal || "Share a moment";
  els.platform.value = settings.platform || profile.defaultPlatform || "Facebook";
  els.postType.value = settings.postType || "Personal";
  els.tone.value = settings.tone || profile.defaultTone || "Natural";
  els.length.value = settings.length || "Medium";
  els.emojiLevel.value = settings.emojiLevel || "None";
  els.hashtagLevel.value = settings.hashtagLevel || "Few";
  els.factMode.value = settings.factMode || "careful";
  els.location.value = settings.location || "";
  els.callToAction.value = settings.callToAction || "";
  els.avoidPhrases.value = settings.avoidPhrases || "";
  setMode(settings.mode || "quick");

  if (useProfileDefaults && !saved) {
    els.platform.value = profile.defaultPlatform || "Facebook";
    els.tone.value = profile.defaultTone || "Natural";
  }
}

function setMode(mode) {
  state.mode = mode === "guided" ? "guided" : "quick";
  document.querySelectorAll(".mode-button").forEach(button => {
    button.classList.toggle("active", button.dataset.mode === state.mode);
  });
  els.guidedFields.classList.toggle("hidden", state.mode !== "guided");
}

async function handleFiles(fileList) {
  const incoming = Array.from(fileList || []).filter(file => file.type.startsWith("image/"));
  const space = MAX_PHOTOS - state.files.length;
  if (space <= 0) return showToast(`Maximum ${MAX_PHOTOS} photos.`);
  const chosen = incoming.slice(0, space);

  setBusy(true, "Preparing photos…");
  try {
    for (const file of chosen) {
      const compressed = await compressImage(file, { maxDimension: 1100, quality: 0.7 });
      state.files.push(file);
      state.compressedImages.push(compressed);
    }
    renderPhotos();
    if (incoming.length > space) showToast(`Only the first ${space} additional photos were added.`);
  } catch (error) {
    showError(error.message || "One of the photos could not be prepared.");
  } finally {
    setBusy(false);
    els.photoInput.value = "";
  }
}

function compressImage(file, options = {}) {
  const targetCharacters = Number(options.targetCharacters || 0);
  const startingDimension = Number(options.maxDimension || 1200);
  const startingQuality = Number(options.quality || 0.72);

  return new Promise((resolve, reject) => {
    const image = new Image();
    const url = URL.createObjectURL(file);

    image.onload = () => {
      try {
        let dimension = startingDimension;
        let lastDataUrl = "";

        while (dimension >= 440) {
          const scale = Math.min(1, dimension / Math.max(image.naturalWidth, image.naturalHeight));
          const width = Math.max(1, Math.round(image.naturalWidth * scale));
          const height = Math.max(1, Math.round(image.naturalHeight * scale));
          const canvas = document.createElement("canvas");
          canvas.width = width;
          canvas.height = height;

          const ctx = canvas.getContext("2d", { alpha: false });
          ctx.fillStyle = "#ffffff";
          ctx.fillRect(0, 0, width, height);
          ctx.drawImage(image, 0, 0, width, height);

          for (const quality of [startingQuality, 0.64, 0.56, 0.48, 0.42]) {
            lastDataUrl = canvas.toDataURL("image/jpeg", quality);
            if (!targetCharacters || lastDataUrl.length <= targetCharacters) {
              resolve(lastDataUrl);
              return;
            }
          }
          dimension = Math.floor(dimension * 0.82);
        }

        resolve(lastDataUrl);
      } catch (error) {
        reject(error);
      } finally {
        URL.revokeObjectURL(url);
      }
    };

    image.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error(`Could not read ${file.name}.`));
    };

    image.src = url;
  });
}

async function prepareUploadImages() {
  if (!state.files.length) return [];
  const perImageBudget = Math.floor(MAX_UPLOAD_CHARACTERS / state.files.length);
  const prepared = [];

  for (const file of state.files) {
    prepared.push(await compressImage(file, {
      maxDimension: 1450,
      quality: 0.76,
      targetCharacters: perImageBudget
    }));
  }

  const totalCharacters = prepared.reduce((sum, image) => sum + image.length, 0);
  if (totalCharacters > MAX_UPLOAD_CHARACTERS) {
    throw new Error("The prepared photos are too large. Remove one photo and try again.");
  }
  return prepared;
}

function renderPhotos() {
  els.photoGrid.innerHTML = "";
  state.files.forEach((file, index) => {
    const item = document.createElement("div");
    item.className = "photo-item";

    const img = document.createElement("img");
    img.alt = `Selected photo ${index + 1}`;
    const previewUrl = URL.createObjectURL(file);
    img.src = previewUrl;
    img.onload = () => URL.revokeObjectURL(previewUrl);

    const number = document.createElement("span");
    number.className = "photo-number";
    number.textContent = index + 1;

    const actions = document.createElement("div");
    actions.className = "photo-actions";

    const left = actionButton("←", "Move photo left", () => movePhoto(index, -1));
    const remove = actionButton("Remove", "Remove photo", () => removePhoto(index), "remove-photo");
    const right = actionButton("→", "Move photo right", () => movePhoto(index, 1));
    left.disabled = index === 0;
    right.disabled = index === state.files.length - 1;

    actions.append(left, remove, right);
    item.append(img, number, actions);
    els.photoGrid.append(item);
  });
  els.photoCount.textContent = `${state.files.length} / ${MAX_PHOTOS}`;
}

function actionButton(text, label, handler, className = "") {
  const button = document.createElement("button");
  button.type = "button";
  button.textContent = text;
  button.setAttribute("aria-label", label);
  button.className = className;
  button.addEventListener("click", handler);
  return button;
}

function movePhoto(index, direction) {
  const target = index + direction;
  if (target < 0 || target >= state.files.length) return;
  [state.files[index], state.files[target]] = [state.files[target], state.files[index]];
  [state.compressedImages[index], state.compressedImages[target]] =
    [state.compressedImages[target], state.compressedImages[index]];
  renderPhotos();
}

function removePhoto(index) {
  state.files.splice(index, 1);
  state.compressedImages.splice(index, 1);
  renderPhotos();
}

function getRecentCaptions(profileId) {
  try {
    const all = JSON.parse(localStorage.getItem(RECENT_STORAGE) || "{}");
    return Array.isArray(all[profileId]) ? all[profileId].slice(0, 8) : [];
  } catch {
    return [];
  }
}

function rememberRecentCaption(caption) {
  if (!caption) return;
  const profileId = els.profileSelect.value;
  let all = {};
  try { all = JSON.parse(localStorage.getItem(RECENT_STORAGE) || "{}"); } catch {}
  const recent = Array.isArray(all[profileId]) ? all[profileId] : [];
  all[profileId] = [caption, ...recent.filter(item => item !== caption)].slice(0, 12);
  localStorage.setItem(RECENT_STORAGE, JSON.stringify(all));
}

function settingsPayload(revisionInstruction = "") {
  const profile = selectedProfile();
  return {
    profileId: profile.id,
    profileName: profile.name,
    profileDescription: profile.description,
    profileVoice: profile.voice,
    profileAvoid: profile.avoid,
    standardHashtags: profile.standardHashtags,
    postGoal: els.postGoal.value,
    postType: els.postType.value,
    tone: state.mode === "quick" ? profile.defaultTone || "Natural" : els.tone.value,
    platform: els.platform.value,
    length: state.mode === "quick" ? "Medium" : els.length.value,
    emojiLevel: state.mode === "quick" ? "None" : els.emojiLevel.value,
    hashtagLevel: state.mode === "quick" ? "Few" : els.hashtagLevel.value,
    factMode: state.mode === "quick" ? "careful" : els.factMode.value,
    context: els.context.value.trim(),
    location: state.mode === "quick" ? "" : els.location.value.trim(),
    mustInclude: state.mode === "quick" ? "" : els.mustInclude.value.trim(),
    callToAction: state.mode === "quick" ? "" : els.callToAction.value.trim(),
    avoidPhrases: state.mode === "quick" ? "" : els.avoidPhrases.value.trim(),
    recentCaptions: getRecentCaptions(profile.id),
    revisionInstruction,
    previousResult: revisionInstruction && state.result ? {
      captions: state.result.captions,
      hashtags: state.result.hashtags
    } : null
  };
}

async function generatePost(revisionInstruction = "") {
  hideError();
  if (!state.files.length) return showError("Add at least one photo first.");

  saveSettingsForProfile();
  setBusy(true, revisionInstruction ? "Rewriting…" : "Preparing photos…");

  try {
    const uploadImages = await prepareUploadImages();
    setBusy(true, revisionInstruction ? "Rewriting…" : "Reading the photos…");

    const response = await fetch("/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        images: uploadImages,
        settings: settingsPayload(revisionInstruction)
      })
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not create the post.");

    state.result = data;
    state.selectedCaptionIndex = 0;
    renderResults();
    els.resultsCard.classList.remove("hidden");
    els.resultsCard.scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (error) {
    showError(error.message || "Could not create the post.");
  } finally {
    setBusy(false);
  }
}

function renderResults() {
  const result = state.result;
  els.resultMode.textContent = result.mode === "ai" ? "AI photo analysis" : "Fallback mode";
  els.resultMode.className = `status-pill compact ${result.mode === "ai" ? "connected" : "fallback"}`;
  els.photoSummary.textContent = result.photoSummary || "";

  renderList(els.visibleFacts, result.visibleFacts, "No specific visual facts were needed.");
  renderList(els.checkBeforePosting, result.checkBeforePosting, "");
  const hasChecks = Array.isArray(result.checkBeforePosting) && result.checkBeforePosting.length > 0;
  els.checkBeforePostingGroup.classList.toggle("hidden", !hasChecks);
  els.factCheckDetails.open = hasChecks;

  els.captionOptions.innerHTML = "";
  result.captions.forEach((caption, index) => {
    const fragment = els.captionTemplate.content.cloneNode(true);
    const card = fragment.querySelector(".caption-card");
    const label = fragment.querySelector(".caption-label");
    const textarea = fragment.querySelector(".caption-text");
    const radio = fragment.querySelector(".caption-choice");
    const copyButton = fragment.querySelector(".copy-caption");

    label.textContent = caption.label;
    textarea.value = caption.text;
    radio.value = index;
    radio.checked = index === state.selectedCaptionIndex;
    if (radio.checked) card.classList.add("selected");

    textarea.addEventListener("input", () => {
      state.result.captions[index].text = textarea.value;
      if (index === state.selectedCaptionIndex) updateCombinedPost();
    });
    radio.addEventListener("change", () => {
      state.selectedCaptionIndex = index;
      [...els.captionOptions.querySelectorAll(".caption-card")].forEach((element, i) => {
        element.classList.toggle("selected", i === index);
      });
      updateCombinedPost();
    });
    copyButton.addEventListener("click", () => {
      const hashtags = els.hashtagsOutput.value.trim();
      const combined = [textarea.value.trim(), hashtags].filter(Boolean).join("\n\n");
      copyText(combined, "Caption and hashtags copied.");
    });

    els.captionOptions.append(fragment);
  });

  els.hashtagsOutput.value = (result.hashtags || []).join(" ");
  els.altTextOutput.value = result.suggestedAltText || "";
  els.platformNote.textContent = result.recommendedPlatformNotes || "";
  updateCombinedPost();
}

function renderList(element, items, emptyText) {
  element.innerHTML = "";
  const safeItems = Array.isArray(items) ? items.filter(Boolean) : [];
  if (!safeItems.length && emptyText) {
    const li = document.createElement("li");
    li.textContent = emptyText;
    element.append(li);
    return;
  }
  safeItems.forEach(item => {
    const li = document.createElement("li");
    li.textContent = item;
    element.append(li);
  });
}

function currentCaption() {
  return state.result?.captions?.[state.selectedCaptionIndex]?.text?.trim() || "";
}

function updateCombinedPost() {
  const caption = currentCaption();
  const hashtags = els.hashtagsOutput.value.trim();
  els.postOutput.value = [caption, hashtags].filter(Boolean).join("\n\n");
}

function completePostText() {
  return els.postOutput.value.trim();
}

async function sharePost() {
  if (!state.result) return;
  rememberRecentCaption(currentCaption());

  const shareData = { title: "Social media post", text: completePostText() };
  const shareableFiles = state.files.filter(file => file instanceof File);

  try {
    if (shareableFiles.length && navigator.canShare?.({ files: shareableFiles })) {
      shareData.files = shareableFiles;
    }
    if (navigator.share) {
      await navigator.share(shareData);
    } else {
      await copyText(shareData.text, "Post copied. Open your social app and paste it.");
    }
  } catch (error) {
    if (error.name !== "AbortError") {
      await copyText(shareData.text, "Sharing was unavailable, so the post was copied.");
    }
  }
}

async function copyText(text, successMessage = "Copied.") {
  try {
    await navigator.clipboard.writeText(text);
    showToast(successMessage);
  } catch {
    const helper = document.createElement("textarea");
    helper.value = text;
    helper.style.position = "fixed";
    helper.style.opacity = "0";
    document.body.append(helper);
    helper.select();
    document.execCommand("copy");
    helper.remove();
    showToast(successMessage);
  }
}

function saveStyleExample() {
  const caption = currentCaption();
  if (!caption) return;

  const profiles = getProfiles();
  const index = profiles.findIndex(profile => profile.id === els.profileSelect.value);
  if (index < 0) return;

  const marker = "Posts I approved:";
  const currentVoice = profiles[index].voice || "";
  const lines = currentVoice.split("\n").filter(Boolean);
  const examples = lines.filter(line => line.startsWith("• ")).slice(-3);
  const base = lines.filter(line => !line.startsWith("• ") && line !== marker).join("\n").trim();
  profiles[index].voice = [base, marker, ...examples, `• ${caption}`].filter(Boolean).join("\n").slice(0, 3500);

  saveProfiles(profiles);
  syncProfileEditor();
  rememberRecentCaption(caption);
  showToast("Saved as a writing example for this profile.");
}

function saveDraft() {
  if (!state.result) return;
  const drafts = getDrafts();
  drafts.unshift({
    id: crypto.randomUUID?.() || String(Date.now()),
    savedAt: new Date().toISOString(),
    profileName: selectedProfile().name,
    platform: els.platform.value,
    caption: currentCaption(),
    hashtags: els.hashtagsOutput.value.trim(),
    altText: els.altTextOutput.value.trim()
  });
  localStorage.setItem(DRAFT_STORAGE, JSON.stringify(drafts.slice(0, 30)));
  rememberRecentCaption(currentCaption());
  renderDrafts();
  showToast("Draft saved on this device.");
}

function getDrafts() {
  try {
    const parsed = JSON.parse(localStorage.getItem(DRAFT_STORAGE) || "[]");
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function renderDrafts() {
  const drafts = getDrafts();
  els.draftList.innerHTML = "";
  if (!drafts.length) {
    const empty = document.createElement("p");
    empty.className = "muted";
    empty.textContent = "No saved drafts yet.";
    els.draftList.append(empty);
    return;
  }

  drafts.forEach(draft => {
    const item = document.createElement("article");
    item.className = "draft-item";

    const heading = document.createElement("strong");
    heading.textContent = `${draft.profileName} • ${draft.platform}`;

    const date = document.createElement("small");
    date.className = "muted";
    date.textContent = new Date(draft.savedAt).toLocaleString();

    const text = document.createElement("p");
    text.textContent = draft.caption;

    const actions = document.createElement("div");
    actions.className = "draft-actions";

    const copy = actionButton("Copy", "Copy saved draft", () =>
      copyText([draft.caption, draft.hashtags].filter(Boolean).join("\n\n"), "Draft copied.")
    );
    copy.className = "secondary";

    const remove = actionButton("Delete", "Delete saved draft", () => {
      const updated = getDrafts().filter(item => item.id !== draft.id);
      localStorage.setItem(DRAFT_STORAGE, JSON.stringify(updated));
      renderDrafts();
    });
    remove.className = "ghost danger";

    actions.append(copy, remove);
    item.append(heading, document.createElement("br"), date, text, actions);
    els.draftList.append(item);
  });
}

function clearPost() {
  state.files = [];
  state.compressedImages = [];
  state.result = null;
  renderPhotos();
  els.context.value = "";
  els.mustInclude.value = "";
  els.resultsCard.classList.add("hidden");
  els.postOutput.value = "";
  els.hashtagsOutput.value = "";
  hideError();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function setBusy(isBusy, label = "Create my post") {
  els.generateBtn.disabled = isBusy;
  document.querySelectorAll(".rewrite-chip").forEach(button => button.disabled = isBusy);
  els.generateLabel.textContent = isBusy ? label : "Create my post";
}

function showError(message) {
  els.formError.textContent = message;
  els.formError.classList.remove("hidden");
}

function hideError() {
  els.formError.textContent = "";
  els.formError.classList.add("hidden");
}

let toastTimer;
function showToast(message) {
  clearTimeout(toastTimer);
  els.toast.textContent = message;
  els.toast.classList.remove("hidden");
  toastTimer = setTimeout(() => els.toast.classList.add("hidden"), 2800);
}

async function checkStatus() {
  try {
    const response = await fetch("/api/status", { cache: "no-store" });
    const status = await response.json();
    if (status.aiConnected) {
      els.aiStatus.textContent = "AI photo analysis connected";
      els.aiStatus.className = "status-pill connected";
    } else {
      els.aiStatus.textContent = "Fallback mode — AI key not connected";
      els.aiStatus.className = "status-pill fallback";
    }
  } catch {
    els.aiStatus.textContent = "App is offline";
    els.aiStatus.className = "status-pill fallback";
  }
}

els.photoInput.addEventListener("change", event => handleFiles(event.target.files));
els.dropZone.addEventListener("dragover", event => {
  event.preventDefault();
  els.dropZone.classList.add("dragover");
});
els.dropZone.addEventListener("dragleave", () => els.dropZone.classList.remove("dragover"));
els.dropZone.addEventListener("drop", event => {
  event.preventDefault();
  els.dropZone.classList.remove("dragover");
  handleFiles(event.dataTransfer.files);
});

document.querySelectorAll(".mode-button").forEach(button => {
  button.addEventListener("click", () => {
    setMode(button.dataset.mode);
    saveSettingsForProfile();
  });
});

els.profileSelect.addEventListener("change", () => {
  syncProfileEditor();
  restoreSettingsForProfile(els.profileSelect.value, true);
});
els.saveProfileBtn.addEventListener("click", saveCurrentProfile);
els.deleteProfileBtn.addEventListener("click", deleteCurrentProfile);
els.generateBtn.addEventListener("click", () => generatePost(""));
document.querySelectorAll(".rewrite-chip").forEach(button => {
  button.addEventListener("click", () => generatePost(button.dataset.revision || ""));
});
els.copyPostBtn.addEventListener("click", () => {
  rememberRecentCaption(currentCaption());
  copyText(completePostText(), "Caption and hashtags copied together.");
});
els.hashtagsOutput.addEventListener("input", updateCombinedPost);
els.copyAltTextBtn.addEventListener("click", () => copyText(els.altTextOutput.value, "Photo description copied."));
els.shareBtn.addEventListener("click", sharePost);
els.copyAllBtn.addEventListener("click", () => {
  rememberRecentCaption(currentCaption());
  copyText(completePostText(), "Complete post copied.");
});
els.saveStyleBtn.addEventListener("click", saveStyleExample);
els.saveDraftBtn.addEventListener("click", saveDraft);
els.newPostBtn.addEventListener("click", clearPost);

[
  els.postGoal, els.platform, els.postType, els.tone, els.length,
  els.emojiLevel, els.hashtagLevel, els.factMode, els.location,
  els.callToAction, els.avoidPhrases
].forEach(element => {
  element.addEventListener("change", saveSettingsForProfile);
});

window.addEventListener("beforeinstallprompt", event => {
  event.preventDefault();
  state.deferredInstallPrompt = event;
  els.installBtn.classList.remove("hidden");
});

els.installBtn.addEventListener("click", async () => {
  if (!state.deferredInstallPrompt) return;
  state.deferredInstallPrompt.prompt();
  await state.deferredInstallPrompt.userChoice;
  state.deferredInstallPrompt = null;
  els.installBtn.classList.add("hidden");
});

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("/sw.js").catch(() => {}));
}

renderProfiles("personal");
renderPhotos();
renderDrafts();
checkStatus();
