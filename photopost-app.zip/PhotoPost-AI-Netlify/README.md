# PhotoPost AI — Netlify edition

An installable, phone-friendly web app that turns uploaded photos into finished social-media captions and hashtags.

## Included

- Up to eight photos
- Automatic photo resizing for Netlify's request-size limit
- AI visual analysis using the OpenAI Responses API
- Three editable captions
- Hashtag suggestions
- Saved posting profiles and local drafts
- Android and iPhone share-sheet support
- Installable Progressive Web App
- Secure server-side OpenAI key through Netlify environment variables
- Fallback caption mode before the AI key is connected

## Deploy

Read `DEPLOY-TO-NETLIFY.md`.

## Project structure

- `public/` — app screens and installable PWA files
- `netlify/functions/` — private server-side API functions
- `lib/` — shared server-side utilities
- `netlify.toml` — publishing, functions, redirects, and security headers

## Local testing

With Node.js 20 or newer:

```bash
npx netlify dev
```

Create a local `.env` file based on `.env.example` to test AI photo analysis.

## Privacy and security

- The OpenAI API key remains server-side.
- Uploaded photos are resized in the browser before transmission.
- This starter does not save uploaded photos.
- Profiles and drafts are saved in the browser's local storage.
- Photos sent for AI analysis are transmitted to the configured OpenAI API project.
