const { jsonResponse } = require("../../lib/post-utils.js");

exports.handler = async function handler(event) {
  if (event.httpMethod !== "GET") {
    return jsonResponse(405, { error: "Method not allowed." }, { "Allow": "GET" });
  }

  return jsonResponse(200, {
    aiConnected: Boolean(process.env.OPENAI_API_KEY),
    model: process.env.OPENAI_MODEL || "gpt-5-mini",
    host: "netlify",
    appVersion: "2.1-combined-post"
  });
};
