const {
  jsonResponse,
  cleanJsonText,
  extractOutputText,
  normalizeResult,
  fallbackGenerate
} = require("../../lib/post-utils.js");

const MAX_IMAGES = 8;
const MAX_BODY_CHARACTERS = 4_200_000;

exports.handler = async function handler(event) {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 204,
      headers: {
        "Allow": "POST, OPTIONS",
        "Cache-Control": "no-store"
      },
      body: ""
    };
  }

  if (event.httpMethod !== "POST") {
    return jsonResponse(405, { error: "Method not allowed." }, { "Allow": "POST, OPTIONS" });
  }

  if (!event.body) {
    return jsonResponse(400, { error: "The request body is empty." });
  }

  if (event.body.length > MAX_BODY_CHARACTERS) {
    return jsonResponse(413, {
      error: "The prepared photos are still too large. Remove one photo or try smaller originals."
    });
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return jsonResponse(400, { error: "Invalid request data." });
  }

  const images = Array.isArray(body.images)
    ? body.images
        .filter(value => typeof value === "string" && /^data:image\/(?:jpeg|png|webp);base64,/i.test(value))
        .slice(0, MAX_IMAGES)
    : [];

  if (!images.length) {
    return jsonResponse(400, { error: "Add at least one photo." });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return jsonResponse(200, { mode: "fallback", ...fallbackGenerate(body) });
  }

  try {
    const result = await generateWithOpenAI(body, images, apiKey);
    return jsonResponse(200, { mode: "ai", ...result });
  } catch (error) {
    console.error("PhotoPost AI generation error:", error);
    return jsonResponse(error.statusCode || 502, {
      error: error.publicMessage || error.message || "The AI request failed."
    });
  }
};

function safe(value, max = 1400) {
  return String(value || "").replace(/\u0000/g, "").trim().slice(0, max);
}

function list(value, maxItems = 8, itemLength = 500) {
  if (!Array.isArray(value)) return [];
  return value.slice(0, maxItems).map(item => safe(item, itemLength)).filter(Boolean);
}

function platformRules(platform, hashtagLevel) {
  const hashtagCounts = {
    Facebook: { Few: "0–3", None: "0", Standard: "3–5" },
    Instagram: { Few: "3–6", None: "0", Standard: "6–10" },
    TikTok: { Few: "2–5", None: "0", Standard: "5–8" },
    LinkedIn: { Few: "1–3", None: "0", Standard: "3–5" },
    X: { Few: "0–2", None: "0", Standard: "1–3" },
    General: { Few: "1–4", None: "0", Standard: "4–7" }
  };
  const count = hashtagCounts[platform]?.[hashtagLevel] || "1–4";

  const notes = {
    Facebook: "Write conversationally. Do not stuff the caption with hashtags.",
    Instagram: "Lead with a strong first line and use line breaks when helpful.",
    TikTok: "Keep it energetic and direct. The caption supports the visual rather than retelling everything.",
    LinkedIn: "Make the point clear and useful. Keep the tone credible.",
    X: "Be concise and stay comfortably within the platform's post length.",
    General: "Keep the copy flexible enough to work across common social platforms."
  };

  return `${notes[platform] || notes.General} Return ${count} relevant hashtags.`;
}

function buildPrompt(settings) {
  const recent = list(settings.recentCaptions, 8, 450);
  const previousCaptions = list(settings.previousResult?.captions, 3, 700)
    .map(item => typeof item === "string" ? item : safe(item?.text, 700));
  const previousHashtags = list(settings.previousResult?.hashtags, 12, 80);

  const factMode = {
    careful: "Use only user-supplied facts and details clearly visible in the photos. If uncertain, omit the claim and add it to checkBeforePosting.",
    balanced: "You may make ordinary low-risk visual descriptions, but do not infer ownership, purchase, location, relationships, taste, quality, results or events.",
    creative: "Use more personality and imagery, but every factual claim must still be grounded in user text or visible evidence."
  }[settings.factMode] || "Use only grounded facts.";

  return `
You are PhotoPost AI, a careful social-media editor for ordinary people and small businesses.

Your job is to turn the attached photos and the user's notes into three useful captions that sound like a real person—not generic marketing copy.

PRIORITY OF INFORMATION
1. The user's explicit context and required facts.
2. Clearly legible words, labels, prices, dates and numbers visible in the photos.
3. Safe visual description.
Never invent missing facts.

USER AND PROFILE
- Profile: ${safe(settings.profileName, 120)}
- What the profile is about: ${safe(settings.profileDescription, 900)}
- Writing voice: ${safe(settings.profileVoice, 2500)}
- Profile habits to avoid: ${safe(settings.profileAvoid, 900)}
- Standard hashtags: ${safe(settings.standardHashtags, 400)}

POST DIRECTION
- Goal: ${safe(settings.postGoal, 100)}
- Post type: ${safe(settings.postType, 100)}
- Platform: ${safe(settings.platform, 50)}
- Tone: ${safe(settings.tone, 50)}
- Length: ${safe(settings.length, 50)}
- Emoji level: ${safe(settings.emojiLevel, 50)}
- Hashtag level: ${safe(settings.hashtagLevel, 50)}
- Accuracy style: ${factMode}
- User context: ${safe(settings.context, 1800) || "No context provided"}
- Location: ${safe(settings.location, 250) || "Not provided"}
- Facts that must be included: ${safe(settings.mustInclude, 1200) || "None"}
- Call to action: ${safe(settings.callToAction, 700) || "None"}
- Additional phrases to avoid: ${safe(settings.avoidPhrases, 700) || "None"}
- Requested rewrite: ${safe(settings.revisionInstruction, 700) || "None"}

ACCURACY RULES
- Read visible text carefully, especially product names, model names, prices, measurements, proof, dates and signage.
- Use a visible word or number only when it is clear enough to read. Otherwise add a short warning to checkBeforePosting.
- Never infer the location from the profile, past posts or scenery. Use a location only when the user entered it or it is unmistakably printed and relevant.
- Do not claim the user bought, owns, opened, tasted, used, installed, completed, attended or recommends something unless the user says so or the image clearly proves it.
- If a shelf photo shows a product, default to "saw," "found" or a neutral description unless the user says it was purchased or tried.
- For food, drinks and products, do not claim taste, quality, performance or value without user-provided experience.
- Do not identify private people.
- If the user's words and the photo appear to conflict, preserve the user's likely intent without repeating the conflicting visual assumption, and mention the uncertainty in checkBeforePosting.
- Use the user's required facts when safe. Do not silently replace them with your own angle.

WRITING RULES
- Sound specific, natural and human.
- Prefer first-person language when it fits the user's context.
- Do not narrate every obvious object in the image.
- Avoid filler and common AI clichés, including: "had to share," "a little look," "one for the camera roll," "game changer," "perfect for," "you won't want to miss," "something for everyone," "won't be shy," and "when things get serious."
- Avoid excessive em dashes, forced enthusiasm, fake questions and vague hype.
- Do not make every caption a sales pitch.
- Emoji setting "None" means no emojis; "Light" means at most 1–2; "Playful" means at most 3.
- ${platformRules(settings.platform, settings.hashtagLevel)}
- If standard profile hashtags are relevant, include them without duplicating them.
- Do not repeat distinctive wording from these recent posts:
${recent.length ? recent.map((item, index) => `${index + 1}. ${item}`).join("\n") : "None"}
- If this is a rewrite, improve on these prior options rather than lightly paraphrasing them:
${previousCaptions.length ? previousCaptions.map((item, index) => `${index + 1}. ${item}`).join("\n") : "None"}
Prior hashtags: ${previousHashtags.join(" ") || "None"}

OUTPUT
Return only valid JSON, with no markdown or explanation, using exactly this shape:
{
  "photoSummary": "one neutral sentence explaining the main subject and likely post situation",
  "visibleFacts": ["short grounded fact", "short grounded fact"],
  "checkBeforePosting": ["only genuine uncertainties that could change the post"],
  "captions": [
    {"label": "Natural", "text": "the best everyday caption"},
    {"label": "Short", "text": "a tighter option"},
    {"label": "More personality", "text": "a distinct option with more voice, not more hype"}
  ],
  "hashtags": ["#RelevantTag"],
  "suggestedAltText": "a concise factual description of the image or image set for accessibility",
  "recommendedPlatformNotes": "one brief, practical posting tip"
}`.trim();
}

async function generateWithOpenAI(body, images, apiKey) {
  const settings = body.settings || {};
  const prompt = buildPrompt(settings);
  const content = [{ type: "input_text", text: prompt }];

  images.forEach((image, index) => {
    content.push({
      type: "input_image",
      image_url: image,
      detail: index < 2 ? "high" : "auto"
    });
  });

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: process.env.OPENAI_MODEL || "gpt-5-mini",
      input: [{ role: "user", content }],
      max_output_tokens: 2400
    })
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const error = new Error(data?.error?.message || `OpenAI returned status ${response.status}.`);
    error.statusCode = 502;
    error.publicMessage = response.status === 401
      ? "The OpenAI API key was rejected. Check the key in Netlify's environment variables."
      : response.status === 429
        ? "The OpenAI account has reached a usage, rate or billing limit."
        : response.status === 400
          ? "The AI request was not accepted. Check the model setting or try fewer photos."
          : "OpenAI could not create the post. Please try again.";
    throw error;
  }

  const outputText = extractOutputText(data);
  let parsed;
  try {
    parsed = JSON.parse(cleanJsonText(outputText));
  } catch {
    const error = new Error("The AI response could not be parsed.");
    error.statusCode = 502;
    error.publicMessage = "The AI response could not be read. Please try again.";
    throw error;
  }

  return normalizeResult(parsed);
}
