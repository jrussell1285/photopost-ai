const {
  jsonResponse,
  cleanJsonText,
  extractOutputText,
  normalizeResult,
  fallbackGenerate
} = require("../../lib/post-utils.js");

const MAX_IMAGES = 8;
const MAX_BODY_CHARACTERS = 4_200_000;

exports.handler = async function handler(event) {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 204,
      headers: {
        "Allow": "POST, OPTIONS",
        "Cache-Control": "no-store"
      },
      body: ""
    };
  }

  if (event.httpMethod !== "POST") {
    return jsonResponse(405, { error: "Method not allowed." }, { "Allow": "POST, OPTIONS" });
  }

  if (!event.body) {
    return jsonResponse(400, { error: "The request body is empty." });
  }

  if (event.body.length > MAX_BODY_CHARACTERS) {
    return jsonResponse(413, {
      error: "The prepared photos are still too large. Remove one photo or try smaller originals."
    });
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return jsonResponse(400, { error: "Invalid request data." });
  }

  const images = Array.isArray(body.images)
    ? body.images
        .filter(value => typeof value === "string" && /^data:image\/(?:jpeg|png|webp);base64,/i.test(value))
        .slice(0, MAX_IMAGES)
    : [];

  if (!images.length) {
    return jsonResponse(400, { error: "Add at least one photo." });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return jsonResponse(200, { mode: "fallback", ...fallbackGenerate(body) });
  }

  try {
    const result = await generateWithOpenAI(body, images, apiKey);
    return jsonResponse(200, { mode: "ai", ...result });
  } catch (error) {
    console.error("PhotoPost AI generation error:", error);
    return jsonResponse(error.statusCode || 502, {
      error: error.publicMessage || error.message || "The AI request failed."
    });
  }
};

async function generateWithOpenAI(body, images, apiKey) {
  const settings = body.settings || {};
  const prompt = `
You are the caption writer inside a simple consumer social-media app.

Analyze all attached photos together and create a post that sounds natural, specific, and human—not like generic AI copy.

User settings:
- Profile name: ${settings.profileName || "Personal"}
- Profile description: ${settings.profileDescription || "General personal account"}
- Post type: ${settings.postType || "Personal"}
- Tone: ${settings.tone || "Friendly"}
- Target platform: ${settings.platform || "Facebook"}
- User context: ${settings.context || "No additional context"}
- Location: ${settings.location || "Not provided"}
- Call to action: ${settings.callToAction || "None"}
- Desired length: ${settings.length || "Medium"}

Rules:
- Do not identify private people by name unless the user supplied their names.
- Do not invent locations, businesses, products, prices, awards, or events.
- If text or a brand label is unclear, describe it generally instead of guessing.
- For a business profile, make the copy useful and credible without exaggerated claims.
- Hashtags must be relevant, not spammy. Use fewer hashtags for Facebook and more for Instagram or TikTok.
- Produce exactly three caption options: "Best choice", "Shorter", and "More personality".
- Return only valid JSON with no markdown.

Required JSON shape:
{
  "photoSummary": "one sentence describing what the photos show",
  "captions": [
    {"label": "Best choice", "text": "caption"},
    {"label": "Shorter", "text": "caption"},
    {"label": "More personality", "text": "caption"}
  ],
  "hashtags": ["#Example"],
  "recommendedPlatformNotes": "one short practical posting tip"
}`.trim();

  const content = [{ type: "input_text", text: prompt }];
  for (const image of images) {
    content.push({ type: "input_image", image_url: image, detail: "auto" });
  }

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: process.env.OPENAI_MODEL || "gpt-5-mini",
      input: [{ role: "user", content }],
      max_output_tokens: 1800
    })
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const error = new Error(data?.error?.message || `OpenAI returned status ${response.status}.`);
    error.statusCode = 502;
    error.publicMessage = response.status === 401
      ? "The OpenAI API key was rejected. Check the key in Netlify's environment variables."
      : response.status === 429
        ? "The OpenAI account has reached a usage or billing limit."
        : "OpenAI could not create the post. Please try again.";
    throw error;
  }

  const outputText = extractOutputText(data);
  let parsed;
  try {
    parsed = JSON.parse(cleanJsonText(outputText));
  } catch {
    const error = new Error("The AI response could not be parsed.");
    error.statusCode = 502;
    error.publicMessage = "The AI response could not be read. Please try again.";
    throw error;
  }

  return normalizeResult(parsed);
}
